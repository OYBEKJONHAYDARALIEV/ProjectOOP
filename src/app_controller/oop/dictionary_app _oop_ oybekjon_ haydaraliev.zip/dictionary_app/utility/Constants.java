package app_controller.oop.dictionary_app.utility;

public interface Constants {



}
