package oop.oop_constructor;

public class ConstructorExample {

    public static void main(String[] args) {


        // constructor -> is block of code that started to works when object has created
        // constructor -> is not method because it doesn't "return" anything and not same as "void"
        // constructor -> its name should be same as class name

        // constructor is special method

        // why we need to use constructor ?


        // Types of constructor  are 3 :

        // 1. Default constructor -> standard, no need to write because it has already written by JAVA

        // 2. No - parametrized constructor -> has written by developer without any parametres

        // 3. Parametrized constructor -> has written by developer with any parametres


    }

}
