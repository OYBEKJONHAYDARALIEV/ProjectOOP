package oop.ussd_mobile.utility;

public interface Constants {

    int MENU_LIST_SUBSCRIBERS = 1;
    int MENU_ADD_SUBSCRIBER = 2;
    int MENU_DELETE_SUBSCRIBER = 3;
    int MENU_SEARCH_SUBSCRIBER = 4;
    int MENU_EXIT = 5;

}
